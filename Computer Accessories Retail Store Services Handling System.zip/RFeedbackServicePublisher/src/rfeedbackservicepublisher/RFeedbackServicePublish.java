package rfeedbackservicepublisher;

public interface RFeedbackServicePublish {
	public String getCustomerFeedback();
}
