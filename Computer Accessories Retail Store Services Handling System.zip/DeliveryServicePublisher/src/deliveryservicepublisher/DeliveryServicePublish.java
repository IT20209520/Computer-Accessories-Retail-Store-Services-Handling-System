package deliveryservicepublisher;

public interface DeliveryServicePublish {
	
	public String getCustomerDeliveryDetails();

}
