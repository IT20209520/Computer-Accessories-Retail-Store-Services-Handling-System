package paymentservicepublisher;

public interface PaymentServicePublish {
	
	public String publishCartService();
	
	public String addPaymentService();

}
