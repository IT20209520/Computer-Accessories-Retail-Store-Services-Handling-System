package cartservicepublisher;

public interface CartServicePublish {
	
	public String publishCartService();
	
	public String addItemToCart();

}
