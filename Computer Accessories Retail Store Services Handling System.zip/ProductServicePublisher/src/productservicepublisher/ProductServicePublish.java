package productservicepublisher;

public interface ProductServicePublish {
	
	public String showProducts();
	
}
